// Base JavaScript for BESshow

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('BESshow JavaScript initialized');
});